class Ranking:
    def __init__(self, *, data_views, data_likes, data_posts):
        self.data_views = data_views
        self.data_likes = data_likes
        self.data_posts = data_posts

    def test_method(self):
        return 'Test Success'